# TweakScale Companion :: OPT :: Known Issues

* The OPT Legacy patches were remade from scratch, "clean room" style.
	+ This means that any error on the old patches from Legacy was fixed, but also will tamper with some savegames. Proceed with caution.
	+ Yes, use [S.A.V.E.](https://forum.kerbalspaceprogram.com/index.php?/topic/94997-1100-save-automatic-backup-system-1100-3173/) ! 
