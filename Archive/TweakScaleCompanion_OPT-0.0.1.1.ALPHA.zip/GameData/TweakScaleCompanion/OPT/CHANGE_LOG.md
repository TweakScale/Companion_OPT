# TweakScale Companion :: OPT :: Change Log

* 2023-1005: 0.0.1.1 (LisiasT) for KSP >= 1.2.2
	+ Updates the Documentation
	+ Implements Issues:
		- [#15](https://github.com/TweakScale/Companion/issues/15) Extend the fix implemented on TweakScaleCompanion_NF#2 to every Companion
* 2020-0809: 0.0.1.0 (LisiasT) for KSP >= 1.2.2
	+ First public (beta) release
	+ Added patches for OPT (Classic & Legacy)
	+ "Clean room" implementation for OPT Legacy.
		- Potential conflicts with older patches from Legacy.
		-  Yes, use [S.A.V.E.](https://forum.kerbalspaceprogram.com/index.php?/topic/94997-1100-save-automatic-backup-system-1100-3173/) !
